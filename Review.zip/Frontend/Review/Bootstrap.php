<?php

use Doctrine\Common\Collections\ArrayCollection;

class Shopware_Plugins_Frontend_Review_Bootstrap extends Shopware_Components_Plugin_Bootstrap
{

    private $jsonInfo = array();

    /**
     * @return array
     * @throws Exception
     */
    private function getInfoFromJson() {
        if (!empty($this->jsonInfo)) {
            return $this->jsonInfo;
        }
        $this->jsonInfo = json_decode(file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . 'plugin.json'), true);
        if ($this->jsonInfo) {
            return $this->jsonInfo;
        } else {
            throw new Exception('The plugin has an invalid version file.');
        }
    }

    public function getInfo() {
        $info = $this->getInfoFromJson();
        return $info;
    }

    /**
     * Returns the version of plugin as string.
     *
     * @throws Exception
     * @return string
     */
    public function getVersion() {
        $info = $this->getInfoFromJson();
        if ($info) {
            return $info['version'];
        } else {
            throw new Exception('The plugin has an invalid version file.');
        }
    }

    /**
     * Returns the version of plugin as string.
     *
     * @throws Exception
     * @return string
     */
    public function getLabel() {
        $info = $this->getInfoFromJson();
        if ($info) {
            return $info['label'];
        } else {
            throw new Exception('The plugin has an invalid version file.');
        }
    }

    /**
     * Aktionen die beim aktivieren des Plugins ausgeführt werden sollen
     *
     * @return array
     */
    public function enable() {
        return [
            'success' => true,
            'invalidateCache' => ['template', 'http'],
        ];
    }

    /**
     * Aktionen die beim deaktivieren des Plugins ausgeführt werden sollen
     *
     * @return array
     */
    public function disable() {
        return [
            'success' => true,
            'invalidateCache' => ['template', 'http'],
        ];
    }

    public function install() {
        $this->subscribeEvents();

        $this->createConfig();
        //$this->translateForm();

        return true;
    }

    public function uninstall() {
        return $this->disable();
    }

    private function createConfig() {
        $form = $this->Form();
        $parent = $this->Forms()->findOneBy(['name' => 'Frontend']);
        $form->setParent($parent);

        $form->setElement('checkbox', 'eanActive', [
            'label' => 'EAN anzeigen',
            'description' => 'Die EAN wird unter der Artikelnummer auf der Produktseite angezeigt.',
            'value' => 0,
            'scope' => Shopware\Models\Config\Element::SCOPE_SHOP
        ]);
        $form->setElement('text', 'shop_id', [
            'label' => 'Shop ID',
            'description' => 'Ihre individuelle shopID, finden Sie in Ihrem ReviewsScore-backend.',
            'required'=>'true',
            'scope' => Shopware\Models\Config\Element::SCOPE_SHOP
        ]);
    }

    /**
     * Translates the plugin form
     */
    private function translateForm() {

        $translation = [
            'en_UK' => [
                'plugin_form' => [
                    'label' => 'Product details with EAN',
                    'description' => 'In the article details page, show the EAN of the item, if it has been deposited!'
                ],
                'eanActive' => [
                    'label' => 'Show EAN',
                    'description' => 'Displays EAN field on the details page under the item number',
                ],
                'shop_id' => [
                    'label' => 'Shop ID',
                    'description' => 'Using for review score plugin',
                ],
            ],
            'de_DE' => [
                'plugin_form' => [
                    'label' => 'Artikeldetail mit EAN',
                    'description' => 'Zeigt in der Artikeldetailseite die EAN Nummer des Artikels an, wenn diese hinterlegt wurde!'
                ],
                'eanActive' => [
                    'label' => 'EAN anzeigen',
                    'description' => 'Die EAN wird unter der Artikelnummer auf der Produktseite angezeigt.',
                ],
                'shop_id' => [
                    'label' => 'Shop ID',
                    'description' => 'Ihre individuelle shopID, finden Sie in Ihrem ReviewsScore-backend.',
                ],
            ],
        ];

        $this->addFormTranslations($translation);
    }

    private function subscribeEvents() {
        $this->subscribeEvent('Shopware_Controllers_Backend_Config_After_Save_Config_Element', 'afterSaveConfig');
        $this->subscribeEvent('Enlight_Controller_Action_PostDispatchSecure_Frontend', 'onFrontendPostDispatch');
//        $this->subscribeEvent('Theme_Compiler_Collect_Plugin_Javascript', 'onCollectPluginJsFiles');
    }

    public function onCollectPluginJsFiles() {
        $jsDir = __DIR__ . '/Views/frontend/_public/js/';

        $js = $jsDir . 'api_bridge_id.js';
        return new ArrayCollection(array($js));
    }

    public function afterSaveConfig() {
        /** @var Shopware\Components\CacheManager $cacheManager */
        $cacheManager = Shopware()->Container()->get('shopware.cache_manager');
        $cacheManager->clearHttpCache();
    }

    public function onFrontendPostDispatch(Enlight_Event_EventArgs $args) {
        /** @var \Enlight_Controller_Action $controller */
        $request = $args->getRequest();
        $controller = $args->get('subject');
        $view = $controller->View();

        if ($request->getControllerName() == 'robots.txt') {
            return;
        }

        if (!Shopware()->Container()->initialized('Shop')) {
            return;
        }

        $gtin = false;
        $sArticle = $view->getAssign('sArticle');
        if (!is_null($sArticle) && isset($sArticle['ean'])) {
            switch (strlen($sArticle['ean'])) {
                case 8:
                    $gtin = 'gtin8';
                    break;
                case 12:
                    $gtin = 'gtin12';
                    break;
                case 13:
                    $gtin = 'gtin13';
                    break;
                case 14:
                    $gtin = 'gtin14';
                    break;
                default:
                    $gtin = false;
            }
        }

        $view->assign('dreiwArticleEAN', [
            'active' => $this->Config()->get('eanActive'),
            'shopId' => $this->Config()->get('shop_id'),
            'eanGtin' => $gtin,
        ]);

        $view->addTemplateDir(__DIR__ . '/Views');
    }

}
